import { Component,OnInit  } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators'; 


@Component({
  selector: 'login',
  templateUrl: './loginnew.html',
  styleUrls: ['./loginnew.css']
})
export class loginnew implements OnInit  {
  title = 'angulardemo';  
  loginForm: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router
    ) {}

    ngOnInit () {
    this.loginForm = this.formBuilder.group({
        username: ['', Validators.required],
        password: ['', Validators.required]
    });

    // reset login status
  //  this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
}
    get f() { return this.loginForm.controls; }

    onSubmit() {
        this.submitted = true;
        this.loading = true;
        // stop here if form is invalid
        console.log(this.loginForm.invalid)
        if (this.loginForm.invalid) {
             
            return;
        } 
        this.router.navigate(['/home'])
        //this.authenticationService.login(this.f.username.value, this.f.password.value)
            // .pipe(first())
            // .subscribe(
            //     data => {
            //         this.router.navigate([this.returnUrl]);
            //     },
            //     error => {
            //        // this.alertService.error(error);
            //         this.loading = false;
            //     });
    }
}
