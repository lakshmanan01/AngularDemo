import { Component,OnInit  } from '@angular/core';
import { service } from '../service'
import { ActivatedRoute, Router } from '@angular/router';



@Component({
    selector: 'api',
    templateUrl: './api.html',
    styleUrls: ['./api.css'] 
  })
  export class api implements OnInit  {
    lists:any = [];

    constructor(public rest:service, private route: ActivatedRoute, private router: Router) { }
    
    ngOnInit () { 
        this.getProducts();


    }

    getProducts() {
        this.lists = [];
        this.rest.getProducts().subscribe((test: {data}) => {
          console.log(test.data);
          this.lists = test.data;
        });
      }

  }