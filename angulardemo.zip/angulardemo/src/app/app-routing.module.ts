import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { loginnew } from './login/loginnew';
import { home } from './home/home';
import { api } from './api/api';

const routes: Routes = [
   { path: '', component: loginnew },
   { path: 'login', component: loginnew },
   { path: 'home', component: home },
   { path: 'api', component: api } 
];
 
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
