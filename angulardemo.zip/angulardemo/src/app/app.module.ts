import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { ReactiveFormsModule }    from '@angular/forms';

import { AppComponent } from './app.component';
import { loginnew } from './login/loginnew';
import { home } from './home/home';
import { api } from './api/api';
import { HttpClientModule } from '@angular/common/http';
import { getHostElement } from '@angular/core/src/render3';

import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,loginnew,home,api
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule 
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
