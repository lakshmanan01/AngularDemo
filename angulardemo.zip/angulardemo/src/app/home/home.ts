import { Component,OnInit  } from '@angular/core';

@Component({
    selector: 'home',
    templateUrl: './home.html',
    styleUrls: ['./home.css']
  })
  export class home implements OnInit  {

    
    ngOnInit () {

    }
  }